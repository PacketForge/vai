#!/bin/bash

# ==============================================================================
# Wazuh Dashboard Rebranding Script (MerIT Vision AI)
#
# This script automates the replacement of logos, spinners, and favicons,
# and updates the browser tab title for a Wazuh dashboard installation.
# It backs up original files before replacing them.
# v2.0 - Updated for multiple favicon support
# ==============================================================================

set -e

# --- Configuration ---
# This is the permanent base directory for all your custom branding assets.
CUSTOM_PIC_DIR="/root/-={MerITSupport}=-/Files/Branding2.0"

# The specific files the script will look for inside the directory above.
CUSTOM_LOGO_SOURCE="${CUSTOM_PIC_DIR}/wazuh_mark_on_light.svg"
CUSTOM_SPINNER_SOURCE="${CUSTOM_PIC_DIR}/spinner_on_light.svg"
CUSTOM_WZD_SVG_SOURCE="${CUSTOM_PIC_DIR}/30e500f584235c2912f16c790345f966.svg"

# The title to be displayed in the browser tab.
CUSTOM_TITLE="MerIT Vision AI"
# --- End Configuration ---

# --- Wazuh Dashboard File Paths ---
LOGO_DEST_1="/usr/share/wazuh-dashboard/plugins/securityDashboards/target/public/wazuh_mark_on_light.svg"
LOGO_DEST_2="/usr/share/wazuh-dashboard/src/core/server/core_app/assets/logos/wazuh_mark_on_light.svg"
SPINNER_DEST_1="/usr/share/wizuh-dashboard/plugins/securityDashboards/target/public/spinner_on_light.svg"
SPINNER_DEST_2="/usr/share/wazuh-dashboard/src/core/server/core_app/assets/logos/spinner_on_light.svg"
WZD_SVG_DEST="/usr/share/wazuh-dashboard/plugins/securityDashboards/target/public/30e500f584235c2912f16c790345f966.svg"
DASHBOARD_CONFIG_FILE="/etc/wazuh-dashboard/opensearch_dashboards.yml"

# --- NEW FAVICON PATHS ---
FAVICON_DEST_DIR="/usr/share/wazuh-dashboard/src/core/server/core_app/assets/favicons"

# --- Main Logic ---

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root. Please use sudo." 
    exit 1
fi

echo "--- Starting Wazuh Dashboard Rebranding Process ---"

# Function to safely back up and replace a file
replace_asset() {
    local source_file="$1"
    local dest_file="$2"
    
    if [ ! -f "$source_file" ]; then
        echo "⚠️  WARNING: Source file not found at '$source_file'. Skipping."
        return
    fi

    if [ -f "$dest_file" ]; then
        echo "Backing up original file: $dest_file"
        cp "$dest_file" "${dest_file}.bak"
        
        echo "Replacing with custom file..."
        cp "$source_file" "$dest_file"
        
        echo "Setting correct permissions..."
        chmod 644 "$dest_file"
        echo "✅ Replaced: $dest_file"
    else
        echo "⚠️  WARNING: Destination file not found at '$dest_file'. This path might have changed in a Wazuh update."
    fi
}

# 1a. Replace main branding assets
echo
echo "--- Replacing Logos and Spinners ---"
replace_asset "$CUSTOM_LOGO_SOURCE" "$LOGO_DEST_1"
replace_asset "$CUSTOM_LOGO_SOURCE" "$LOGO_DEST_2"
replace_asset "$CUSTOM_SPINNER_SOURCE" "$SPINNER_DEST_1"
replace_asset "$CUSTOM_SPINNER_SOURCE" "$SPINNER_DEST_2"
replace_asset "$CUSTOM_WZD_SVG_SOURCE" "$WZD_SVG_DEST"

# 1b. Replace all Favicon assets
echo
echo "--- Replacing Favicons ---"
# Add any other favicon filenames you have to this list
FAVICON_FILES=(
    "favicon.ico"
    "favicon.svg"
    "apple-touch-icon.png"
    "favicon-16x16.png"
    "favicon-32x32.png"
)

for favicon in "${FAVICON_FILES[@]}"; do
    local_source="${CUSTOM_PIC_DIR}/${favicon}"
    local_dest="${FAVICON_DEST_DIR}/${favicon}"
    replace_asset "$local_source" "$local_dest"
done


# 2. Update the Title
echo
echo "--- Updating Browser Tab Title ---"
echo "Setting title in $DASHBOARD_CONFIG_FILE..."
SETTING_KEY="opensearchDashboards.branding.applicationTitle"
# Remove the old setting if it exists to prevent duplicates
if grep -q "^${SETTING_KEY}:" "$DASHBOARD_CONFIG_FILE"; then
    sed -i "/^${SETTING_KEY}:/d" "$DASHBOARD_CONFIG_FILE"
fi
# Add the new setting to the end of the file
echo "${SETTING_KEY}: \"${CUSTOM_TITLE}\"" >> "$DASHBOARD_CONFIG_FILE"
echo "✅ Title updated to: '$CUSTOM_TITLE'"

# 3. Restart the Dashboard Service
echo
echo "--- Finalizing Changes ---"
echo "Restarting the Wazuh dashboard service to apply all changes..."
systemctl restart wazuh-dashboard

echo
echo "--- Rebranding Complete! ---"
echo "The dashboard service is restarting. It may take a minute to become available."
echo "Remember to do a HARD REFRESH in your browser (Ctrl+Shift+R or Cmd+Shift+R) to see the changes."